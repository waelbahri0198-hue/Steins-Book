@extends('layouts.app_auth')

@section('script')


<script type="text/javascript"> const UPDATE= "{{route('search_people')}}"</script>
<script type="text/javascript"> const FOLLOW= "{{route('search_people.follow')}}"</script>
<script type="text/javascript"> const UNFOLLOW= "{{route('search_people.unfollow')}}"</script>


<script src="{{asset('js/search_people.js')}}" defer></script>
@endsection

@section('style')
<link href="{{asset('css/search_people.css')}}" rel="stylesheet">
@endsection

@section('title', "RICERCA UTENTI");

@section('content')
<header>
            <div class="Contenitore">
                <div class="spazioTitoli">
                </div>
            </div>
        </header>
    <body>

        

        
        
        <div id="libreriaContainer">
                <!-- sezione di ricerca -->
                    <div id="searchBox" >
                    <form name ='search-form' action = "{{route('search_people.do_search')}}">
                     @csrf
                    <input type="text"  id="searchtext" placeholder="Digita un username">
                    <input type="submit" value='Cerca' id="btntext">
                    </form>
                    </div>

                    <section>
                <div class='grid'>
                </div>
                <div id="ricerca">
    <form name ='ricerca_utenti_form' action = "{{route('search_people.do_search')}}">
        
        <p>
        <label>"Ricerca tutti gli utenti"<label>&nbsp; <input type="submit"  id="ricercaTutti" value="Cerca" ></label>
        
        </p>
    </form>
</div>


<div id="listaContenuti">

</div>
        
                    </section>
            </div>

</body>

@endsection


