@extends('layouts.app_auth')

@section('title', "HOME");

@section('style')
    <link href="{{ asset('css/home.css') }}" rel="stylesheet">
@endsection

@section('script')

<script type="text/javascript"> const ADD_LIKE= "{{route('update_home.add_like')}}"</script>
<script type="text/javascript"> const REMOVE_LIKE= "{{route('update_home.remove_like')}}"</script>
<script type="text/javascript"> const SHOW_LIKE= "{{route('show_like')}}"</script>

    <script src='{{asset('js/home.js')}}' defer="true"></script>
@endsection

@section('content')
<html>
    <body>
        <main>


<form name='form_refresh' refresh="{{('refreshPost')}}" method="post">
    @csrf
    <input id="refreshPost" type='hidden' name='refreshPost' value="{{route('refreshPost')}}">
    <input id="route_update_home" type='hidden' name='route_update_home' value="{{route('update_home')}}">

</form>




<section class="result_view">
</section>

<section id="modal-view" class="hidden">
<div id="box"></div>
</section>

</main>
</body>

</html>

@endsection
