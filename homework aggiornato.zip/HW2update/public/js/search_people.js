function onJson(json){
    console.log(json);
   const grid= document.querySelector('.grid');
   grid.innerHTML='';

    for(utente of json){

        const username= document.createElement("div");
        username.textContent=utente.username;

        const img= document.createElement('img');
        img.src=utente.photo;

        const br= document.createElement('br');

        const follow= document.createElement("button");
        follow.classList.add('btn');
        follow.setAttribute('data-id',utente.id);
        follow.setAttribute('id',"follow");
        follow.innerHTML = 'Follow';



        const unfollow=document.createElement('button');
        unfollow.setAttribute('data-id',utente.id);
        unfollow.innerHTML='Unfollow';



        follow.addEventListener('click',followPeople);
        unfollow.addEventListener('click',unfollowPeople);



        const result = document.createElement("div");
        result.classList.add("result");
        grid.appendChild(result);
        result.appendChild(username);
        result.appendChild(img);
        result.appendChild(br);
        result.appendChild(follow);
        result.appendChild(unfollow);



    }
}



function onResponse(response){
    console.log('Risposta ricevuta');
    return response.json();
}

function searchPeople(event){
    event.preventDefault();
    var token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
    const formdata = new FormData();
    formdata.append('search_people', document.querySelector('#searchtext').value);
    formdata.append('_token', token);

    fetch(form.getAttribute('action'), {method: 'POST', body:formdata}).then(onResponse).then(onJson);

}


function onText(text){
    
    if(parseInt(text)==1)
    alert("utente gia seguito");
    else if(parseInt(text)==0){
    alert("non segui piu");
    }
    console.log(text);





}
function responseFollow(response){
    console.log("Risposta follow ricevuta");
    return response.text();
}



function followPeople(event){
    var token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
   const followed= event.currentTarget.dataset.id;
   console.log(followed);
   event.currentTarget.removeEventListener('click',followPeople);
   event.currentTarget.addEventListener('click',unfollowPeople);
   const formdata = new FormData();
   formdata.append("followed",followed);
   formdata.append('_token',token);
   fetch(FOLLOW,{method:"post", body:formdata}).then(responseFollow); 
   //fetch("follow_people.php",{method:"post", body:formdata}).then(responseFollow).then(onText);



}

function unfollowPeople(event){
    const unfollow = event.currentTarget.dataset.id;
    event.currentTarget.removeEventListener('click',unfollowPeople);
   event.currentTarget.addEventListener('click',followPeople);
    fetch(UNFOLLOW+'?unfollow='+unfollow).then(responseFollow);
 }


 //PARTE MIA

 function onJSONALL(json) {
    console.log(json);
    contenitore = document.getElementById("listaContenuti");
    contenitore.innerHTML = "";

    for (utente of json) {
        contenitoreUtente = document.createElement("div");
        contenitore.appendChild(contenitoreUtente);
        contenitoreUtente.classList.add("utente");
        paragrafo = document.createElement("p");
        paragrafo.dataset.id = "nome_cognome";

        contenitoreUtente.appendChild(paragrafo)

        nome = document.createElement("span");
        cognome = document.createElement("span");
        paragrafo.appendChild(nome);
        paragrafo.appendChild(cognome);
        nome.textContent = utente.nome;
        cognome.textContent = " " + utente.cognome;
        contenitoreImmagine = document.createElement("div");
        contenitoreUtente.appendChild(contenitoreImmagine);
        contenitoreImmagine.classList.add("immagine");
        immagine = document.createElement("img");
        immagine.classList.add("contenuto");
        contenitoreImmagine.appendChild(immagine);
        immagine.src = "immagini/utenti/" + utente.url_Immagine;
        username = document.createElement("p");
        contenitoreUtente.appendChild(username);
        username.textContent = utente.username;
        username.dataset.id = "username";
    }
}




function responseRicerca(response) {
    return response.json();
}




function cercaTutti() {
    event.preventDefault();

    let form_data = new FormData();
    form_data.append("servizio", "ricercaTutti");
    fetch(percorso + "{{route('search_people.do_search')}}", {
        method: "POST",
        body: form_data
    }).then(responseRicerca).then(onJSONALL);
}


const form = document.forms['search-form'];
form.addEventListener('submit',searchPeople);
const percorso = "http://151.97.9.184/cilia_federicoluca/Homework_uno/";