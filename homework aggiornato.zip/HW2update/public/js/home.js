let elem_select;
function onJson(json)
{
  console.log(json);
  const results = document.querySelector('.result_view');
  results.innerHTML = '';

  for(const elementi of json){

    const result_box= document.createElement('div');
    result_box.classList.add('result_box');

    const img_box= document.createElement('div');
    img_box.classList.add('img_box');

    const name_box= document.createElement('div');
    name_box.classList.add('name_box');

    const text_box= document.createElement('div');
    text_box.classList.add('text_box');

    const img = document.createElement('img');
    img.src = elementi.url;

    const name= document.createElement('span');
    name.textContent=elementi.username;

    const testo_post= document.createElement('span');
    testo_post.textContent=elementi.text;

    const like_box= document.createElement('div');
    like_box.classList.add('like_box');

    const data= document.createElement('div');
    data.classList.add('data');
    data.textContent = elementi.data;




    const img_like_post = document.createElement('img');
    img_like_post.post_id=elementi.id;

    const num_like= document.createElement('div');
    num_like.textContent=elementi.num_like;
    num_like.addEventListener('click', showLikes)


      if(elementi.like_view == 1) {

        img_like_post.src='images/loving.png';
        img_like_post.addEventListener('click', unLike);
      }else {

        img_like_post.src='images/ticker.png';
        img_like_post.addEventListener('click', onLike);
      }

      like_box.appendChild(img_like_post);
      like_box.appendChild(num_like);
      name_box.appendChild(name);
      img_box.appendChild(img);
      text_box.appendChild(testo_post);

      result_box.appendChild(name_box);
      result_box.appendChild(img_box);
      result_box.appendChild(text_box);
      result_box.appendChild(like_box);
      result_box.appendChild(data);


      results.appendChild(result_box);
  }
}

function onResponse(response){
    return response.json();
}

function refreshPost(event){
    if(event){
        event.preventDefault();
    }
}

/*var token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
    const form_data = {method: 'post', headers: {"X-CSRF-TOKEN": token}};
    fetch(document.getElementById('route_update_home').value, form_data).then(onResponse).then(onJSON);*/

//fetch(form.getAttribute("refresh")).then(onResponse).then(onJson);
//fetch(document.getElementById("refreshPost")).then(onResponse).then(onJson);


function jsonUnLike(json){
  //let like_box = document.getElementById('route_do_like1');
  let change_img= like_box.querySelector('img');
  let change_num_like= like_box.querySelector('div');
  change_img.src = 'images/ticker.png';
  change_img.removeEventListener('click', unLike);
  change_img.addEventListener('click', onLike);
  change_num_like.textContent=json[0];
  return console.log(json);
}


function responseUnLike(response){
  console.log("2");
  return response.json();
}

function unLike(event){
    const postId=event.currentTarget.dataset.id;
    //elem_select= event.target;
    console.log("unLike");
    fetch(REMOVE_LIKE+"?id=" + postId).then(responseUnLike).then(jsonUnLike);
    event.preventDefault();
}

/*function unLike(event){
    event.preventDefault();
    elem_select= event.target;
    console.log("unLike");
    fetch("http://151.97.9.184/bellavia_giuseppe/hw1/home.php?id_post_unLike="+elem_select.parentNode.id).then(responseUnLike).then(jsonUnLike);
}*/


function jsonOnLike(json){

  let like_box = document.getElementById(elem_select.parentNode.postId);
  let change_img= like_box.querySelector('img');
  let change_num_like= like_box.querySelector('div');
  change_img.src = 'images/loving.png';
  change_img.removeEventListener('click', onLike);
  change_img.addEventListener('click', unLike);
  change_num_like.textContent=json[0];
  return console.log(json);
}


function responseOnLike(response){
    console.log("1");
  return response.json();
}

function onLike(event){
    const postId=event.currentTarget.post_id;
    console.log(postId, event.currentTarget);

      elem_select= event.currentTarget;
      var token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
      const formdata= new FormData();
      formdata.append("postId",postId);
      formdata.append('_token',token);
      console.log("onLike");
      fetch(ADD_LIKE,{method:"post",body:formdata}).then(responseOnLike).then(jsonOnLike);
      event.preventDefault();
  }

/*function onLike(event){
  event.preventDefault();
    elem_select= event.currentTarget;
    console.log("onLike");
    fetch("http://151.97.9.184/bellavia_giuseppe/hw1/home.php?id_post_onLike="+elem_select.parentNode.id).then(responseOnLike).then(jsonOnLike);
}*/

function showLikes(event){
  event.preventDefault();
  const idshow = event.target;
    modalview.classList.remove('hidden');
    fetch("http://151.97.9.184/bellavia_giuseppe/hw1/like_modal.php?idshow="+idshow.parentNode.id).then(responseShow).then(onJsonShow);
}

function onModalClick() {
  document.body.classList.remove('no-scroll');
  modalview.classList.add('hidden');
  modalbox.innerHTML = '';
}

function responseShow(response){
  console.log("risposta show ricevuta");
  return response.json();
}

function onJsonShow(json){
  console.log(json);

  for(utente of json){
      const panel = document.createElement('div');
      panel.classList.add("panel");
      const modalimage=document.createElement("img");
      modalimage.src=utente.profilepic;
      const modalname=document.createElement("span");
      modalname.classList.add("username");
      modalname.textContent=utente.username;

      modalbox.appendChild(panel);
      panel.appendChild(modalimage);
      panel.appendChild(modalname);
  }
  modalview.appendChild(modalbox);
  document.body.classList.add('no-scroll');

  modalview.style.top=window.pageYOffset + 'px';
  modalview.classList.remove('hidden');
}

var token = document.querySelector("meta[name='csrf-token']").getAttribute("content");
const form_data = {method: 'post', headers: {"X-CSRF-TOKEN": token}};
form_data.append=("_token", token);
fetch(document.getElementById('route_update_home').value, form_data).then(onResponse).then(onJson);

const modalbox=document.querySelector('#box');

const modalview = document.querySelector('#modal-view');
modalview.addEventListener('click', onModalClick);


