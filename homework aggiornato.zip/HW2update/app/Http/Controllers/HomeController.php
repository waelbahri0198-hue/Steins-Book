<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\DB;
use App\Models\Like;
use App\Models\Post;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $name = Auth::user();
        return view('home', [
            "name"=>$name->name
            ]);
    }

/*public function refreshPost(Request $request){
    $name=Auth::user();
    $query= DB::select("SELECT users.username, post.type, post.text, post.url, count(likes.userlike_id) as likes from users join post on users.id=post.post_id join follows on follows.followed_id=users.id left join likes on likes.idpost_id=post.id where follows.follower_id = ? group by post.data order by post.data desc", [$name->username]);
    //$query = DB::select("select users.username, post.data, post.tipe, post.text, post.url, count(likes.userlike_id) as likes from users join post on users.id=post.post_id join follows on follows.followed_id=users.id left join likes on likes.idpost_id=post.id where follows.follower_id= ? group by post.data order by post.data desc", [$name->username]);
    return response()->json($query);
}*/

public function update_home(){
    $name = Auth::user()->id;
 // $query = DB::select("select distinct post.id, post.data, users.id, users.username, post.text, post.url from post join users on users.id=post.username_id  order by post.data desc", [$name->id]);
 $query = DB::select("SELECT post.id,post.url,post.text,
 users.id, post.data,users.username
  from post join users on post.username_id=users.id
 where users.id like '".$name."'
 or users.id in (select followed_id from follows
 where follower_id like '".$name."') order by data desc");
return response()->json($query);
 //$query = DB::select("select distinct post.id, post.data, users.id, users.username, post.text, post.url from post left join users", [$name->id]);
 /*$query = DB::select('select distinct post.id, post.data, users.id, users.username, post.text, post.url from post left join users
  on users.id=post.username_id where users.id = ? or users.id in(select follows.followed_id from follows where follows.follower_id = ?) group by post.data ', [$name->id, $name->id]);*/
   // return response()->json($query);
}

public function add_like(Request $request){
    $user=Auth::user();
    $user->post_like()->attach($request->postId);
}

public function remove_like(Request $request){
    $user=Auth::user();
    $user->post_like()->detach($request->id);
}

public function show_like(Request $request){
    $user= Auth::user();
    $show=DB::select("select username, photo from likes_2 join users on user_id=id where post_id=?", [$request->idshow]);
    return $show;
}

/*public function do_like(Request $request){
    $user = Auth::user();
    $post = $request->post;
    $condition = Like::select("select likes.idpost_id, users.username from users join likes on likes.userlike_id=users.id where users.username = ?", [$user->username]);
    if($condition){
        return false;
    }else{
        Like::create([
            'idpost_id' => $post,
            'userlike_id' => $user->id
        ]);
        return true;
    }


}


public function do_like1(Request $request){
    $user = Auth::user();
    $post = $request->post;
    $condition = Like::where("idpost_id", $post)
                        ->where("userlike_id", $user->id)
                        ->first();
    if($condition){
        return false;
    }else{
        Like::create([
            'idpost_id' => $post,
            'userlike_id' => $user->id
        ]);
        return true;
    }


}*/


/*public function like(Request $request){
    $user = Auth::user();
    $post = $request->post;
    $condition = Like::where("userlike_id", $user->username)
                        ->where("idpost_id", $post)
                        ->first();
    if($condition){
        return false;
    }else{
        Like::create([
            'userlike_id' => $user->username, //prelevo lo username dalla classe $user
            'idpost_id' => $post
        ]);
        return true;
    }
}

public function list_like(Request $request){
    $list = Like::where("post", '=', $request->post)->get();
    return response()->json($list);
}*/

}
